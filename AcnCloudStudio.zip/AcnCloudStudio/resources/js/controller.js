AcnCloudStudio
  
  .controller('LeftCtrl', function ($scope, $timeout) {
      $('[data-toggle="offcanvas"]').bind('click', function () {
	      $('.row-offcanvas').toggleClass('active')
	  });
      
      angular.element("#sidebar .leftSideBar-itemsCntr .list-group").find("a").click(function(){
    	  $(this).siblings().removeClass('active');
    	  $(this).addClass("active");
      })
      //#sidebar .leftSideBar-itemsCntr .list-group a
   })

  .controller('dashboardCtrl', function ($scope) {
	  
   })
   
   .controller('createCtrl', function ($scope, $timeout, Createservice_serv, CreateService_Fact) {
	   $scope.createCtrlScope = {};
	   $scope.createCtrlScope.activeModule = "create_serviceMix.html";
	   Createservice_serv.createCtrlScope = $scope.createCtrlScope;
	   
	   /******* Service Mix *******/
	   $scope.serviceMixList =[{name:'Web'}];
	   $scope.submitServiceMix = function(){
		    $scope.createCtrlScope.activeModule = "create_nativeStack.html";
	   }
	   
	   /******* Native Stack *******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_nativeStack.html"){
			   $scope.nativeStackList =[{name:'Spring, Spring Cloud, Spring Data'},{name:'Spring, Spring Cloud, Spring XD'}];
			   $scope.submitnativeStack = function(){
			    	$scope.createCtrlScope.activeModule = "create_dataStore.html";
			   }
		   }  
	   });
	   
	   /******* Data store *******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_dataStore.html"){
			   $scope.dataStoreList = [{ web:[{name:'MySQL'}, {name:'Postgres'}, {name:'MongoDB'}], iot:['Pivotal XD', 'GreenPlum']}];
			   $timeout(function(){
			   //$scope.$watch('formLoaded', function(){
				   $('#dataStore').multiselect({includeSelectAllOption: true});
				   //alert()
			   //})
			  },50)
			   
			   $scope.c_dataStoreList = $scope.dataStoreList[0][$scope.createCtrlScope.serviceMix.name.toLowerCase()]
			   $scope.submitdataStore = function(){
			       $scope.createCtrlScope.activeModule = "create_cachingSolution.html";
			   }
		   }
	   });
	   
	   /******* Caching Solution *******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_cachingSolution.html"){
			   $scope.cachingSolutionList = [{name:'Redis'},{name:'Mamcahce'}];
			   $scope.submitcachingSolution = function(){
				   $("#cacheSolModal").modal('show');
			   }
			   
			   $scope.submitcnfmUIgen = function(){
				   $("#cacheSolModal").modal('hide');
				   $timeout(function(){
					   $scope.createCtrlScope.activeModule = "create_UIgenPltfm.html";
				   },300)
			   }
		   }
	   });
	   
	   
	   /******* UI Generation *******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_UIgenPltfm.html"){
			   $scope.UIgenPltfmList = [{name:'Angular Js'},{name:'Thymeleaf'}];
			   $scope.submitUIgenPltfm = function(){
				   $("#intPfmModal").modal('show');
			   }
			   
			   $scope.submitCnfIntPtfm = function(){
				   $("#intPfmModal").modal('hide');
				   $timeout(function(){
					   $scope.createCtrlScope.activeModule = "create_folderGen.html";
				   },200);
			   }
		   }
	   });
	   
	   /******* Folder name generation and Final submission*******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_folderGen.html"){
			   $scope.submitfolderGen = function(){
				   /********Submit Integration platform***********/ 
				   var dataP = Createservice_serv.createCtrlScope;
				   dataP = {
				    		"microservices":[dataP.serviceMix.name, dataP.cachingSolution.name, dataP.uiGenerationPlatform.name],
				    		"folderName":dataP.folderGenName
				    		}
				   
						   angular.forEach(Createservice_serv.createCtrlScope.dataStore, function(v,k){
							   dataP.microservices.push(v.name);
						   })
				   console.log(Createservice_serv.createCtrlScope)
				   CreateService_Fact.submit_newService(dataP).then(function(dataR){
						alert('Success');
				   });
			   }   
		   }
	   });
   })
   
   .controller('calibrateCtrl', function ($scope) {
      
   })
   
   .controller('containerizeCtrl', function ($scope) {
      
   })