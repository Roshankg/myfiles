AcnCloudStudio
  
  .controller('LeftCtrl', function ($scope, $timeout) {
	  $scope.sideBar_items = [{name:'Create'}, {name:'Calibrate'}, {name:'Containerize'}]
	  
      $('#sideBar_toggleBtn').on('click', function () {
	      $('.row-offcanvas').toggleClass('active')
	  });
      
      $scope.sideBarElement_active = function(elem){
    	  $('.row-offcanvas').toggleClass('active');
    	  $scope.sideBar_activeItem = elem.$id;
    	  sessionStorage.sideBar_activeItem = $scope.sideBar_activeItem;
      } 
      if(sessionStorage.sideBar_activeItem){
    	  $scope.sideBar_activeItem = sessionStorage.sideBar_activeItem;
      }
   })

  .controller('dashboardCtrl', function ($scope) {
	  $scope.$parent.sideBar_activeItem = null;
   })
   
   .controller('createCtrl', function ($scope, $timeout, Createservice_serv, CreateService_Fact) {
	   
	   $scope.createCtrlScope = {};
	   $scope.createCtrlScope.headerQueue = [];
	   $scope.createCtrlScope.activeModule = "create_serviceMix.html";
	   Createservice_serv.createCtrlScope = $scope.createCtrlScope;
	   
	   
	   /****************Header manipulations***************/
	   $scope.createServView_header = function(header){
		   $scope.createCtrlScope.headerQueue.push(header);
		   var queueLength = Createservice_serv.createCtrlScope.headerQueue.length;
		   
		   $scope.createCtrlScope.viewToRender = Createservice_serv.createCtrlScope.headerQueue[queueLength-1];
	   }
	   $scope.bc_renderView = function(itemNo, bc_url){
		   $scope.createCtrlScope.headerQueue.splice(itemNo, $scope.createCtrlScope.headerQueue.length);
		   $scope.createCtrlScope.activeModule = bc_url;
	   }
	   
	   /******* Service Mix *******/
	   $scope.serviceMixList =[{name:'Web'}];
	   $scope.submitServiceMix = function(){
		    $scope.createCtrlScope.activeModule = "create_nativeStack.html";
	   }
	   
	   /******* Native Stack *******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_nativeStack.html"){
			   $scope.nativeStackList =[{name:'Spring, Spring Cloud, Spring Data'},{name:'Spring, Spring Cloud, Spring XD'}];
			   $scope.submitnativeStack = function(){
			    	$scope.createCtrlScope.activeModule = "create_dataStore.html";
			   }
		   }  
	   });
	   
	   /******* Data store *******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_dataStore.html"){
			   $scope.dataStoreList = [{ web:[{name:'Mysql'}, {name:'Postgresql'}, {name:'Mongodb'}], iot:['Pivotal XD', 'GreenPlum']}];
			   $timeout(function(){
			   //$scope.$watch('formLoaded', function(){
				   $('#dataStore').multiselect({includeSelectAllOption: true});
				   //alert()
			   //})
			  },50)
			   
			   $scope.c_dataStoreList = $scope.dataStoreList[0][$scope.createCtrlScope.serviceMix.name.toLowerCase()]
			   $scope.submitdataStore = function(){
			       $scope.createCtrlScope.activeModule = "create_cachingSolution.html";
			   }
		   }
	   });
	   
	   /******* Caching Solution *******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_cachingSolution.html"){
			   $scope.cachingSolutionList = [{name:'Redis'},{name:'Mamcahce'}];
			   $scope.submitcachingSolution = function(){
				   $scope.createCtrlScope.activeModule = "create_UIgenPltfm.html";
			   }
			   
			   
		   }
	   });
	   
	   
	   /******* UI Generation *******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_UIgenPltfm.html"){
			   $scope.UIgenPltfmList = [{name:'Angularjs'},{name:'SpringMVCThymeleaf'}];
			   $timeout(function(){$("#cnfmUIgenPltfm_Modal").modal({
	                   backdrop: 'static',
	                   keyboard: true, 
	                   show: true
	           });},100)
			   
			   $scope.submitcnfmUIgen = function(){
				   $("#cnfmUIgenPltfm_Modal").modal('hide');
				   $('body').removeClass('modal-open');
				   $('.modal-backdrop').remove();
				   if(!$scope.createCtrlScope.confirm_UIGeneration){
					   $scope.createCtrlScope.activeModule = "create_IntgnPlfm.html";
				   }
			   }
			   
			   $scope.submitUIgenPltfm = function(){
				   $scope.createCtrlScope.activeModule = "create_IntgnPlfm.html";
			   }
		   }
	   });
	   
	   
	   /******* Integration Platform *******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_IntgnPlfm.html"){
			   $scope.intgnPltfmList = [{name:'RabbitMQ'}];
			   $timeout(function(){$("#intPfmModal").modal({
	                   backdrop: 'static',
	                   keyboard: true, 
	                   show: true
	           });},100)
			   
			   $scope.submitCnfIntPtfm = function(){
				   $("#intPfmModal").modal('hide');
				   $('body').removeClass('modal-open');
				   $('.modal-backdrop').remove();
				   if(!$scope.createCtrlScope.confirm_integrationPlatform){
					   $scope.createCtrlScope.activeModule = "create_folderGen.html";
				   }
			   }
			   
			   $scope.submitIntgnPlfm = function(){
				   $scope.createCtrlScope.activeModule = "create_folderGen.html";
			   }	   
		   }
	   });
	   
	   /******* Folder name generation and Final submission*******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_folderGen.html"){
			   
			   $scope.submitfolderGen = function(){
				   /********Submit Integration platform***********/ 
				   var dataP = Createservice_serv.createCtrlScope;
				   dataP = {
				    		"microservices":[dataP.cachingSolution.name],
				    		"folderName":dataP.folderGenName
				    		}
				   if(Createservice_serv.createCtrlScope.uiGenerationPlatform)
					   {dataP.microservices.push(Createservice_serv.createCtrlScope.uiGenerationPlatform.name)}
					
				   if(Createservice_serv.createCtrlScope.integrationPlatform)
					   {dataP.microservices.push(Createservice_serv.createCtrlScope.integrationPlatform.name)}   
				   
						   angular.forEach(Createservice_serv.createCtrlScope.dataStore, function(v,k){
							   dataP.microservices.push(v.name);
						   })
				   console.log(Createservice_serv.createCtrlScope)
				   CreateService_Fact.submit_newService(dataP).then(function(dataR){
						//alert('Success');
				   });
			   }   
		   }
	   });
   })
   
   .controller('calibrateCtrl', function ($scope) {
      
   })
   
   .controller('containerizeCtrl', function ($scope) {
      
   })