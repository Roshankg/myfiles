AcnCloudStudio

.factory('CreateService_Fact', function($http, $q, UiNotification){
	return{
		submit_newService: function(dataP){
								var deferred = $q.defer();
								console.log(dataP);
								$http.post('buildSkelton', dataP).success(function(dataR) {
									if(dataR){
										UiNotification.addAlert({type: 'success', msg: 'Application skelton have been downloaded under C:/'+dataP.folderName});
									}else {
										UiNotification.addAlert({type: 'danger', msg: 'Please check if the folder already exist. This tool need to create new Folder with the name '+dataP.folderName});
									}
									deferred.resolve(dataR);
							    }).error(function(error, status, headers, config) {
							    	  UiNotification.addAlert({type: 'danger', msg: 'Failed to Save'});
							    	  deferred.reject(error);
							    });
							    return deferred.promise;
		}
	}	
})