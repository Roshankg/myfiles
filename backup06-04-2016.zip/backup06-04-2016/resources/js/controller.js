AcnCloudStudio
  
  .controller('LeftCtrl', function ($scope, $timeout) {
      $('#sideBar_toggleBtn').on('click', function () {
	      $('.row-offcanvas').toggleClass('active')
	  });
      
      $("#sidebar .leftSideBar-itemsCntr .list-group a").off().on('click', function(){
    	  $('.row-offcanvas').toggleClass('active')
    	  $(this).siblings().removeClass('active');
    	  $(this).addClass("active");
      });
      
   })

  .controller('dashboardCtrl', function ($scope) {
	  
   })
   
   .controller('createCtrl', function ($scope, $timeout, Createservice_serv, CreateService_Fact) {
	   $scope.createCtrlScope = {};
	   $scope.createCtrlScope.activeModule = "create_serviceMix.html";
	   Createservice_serv.createCtrlScope = $scope.createCtrlScope;
	   
	   /******* Service Mix *******/
	   $scope.serviceMixList =[{name:'Web'}];
	   $scope.submitServiceMix = function(){
		    $scope.createCtrlScope.activeModule = "create_nativeStack.html";
	   }
	   
	   /******* Native Stack *******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_nativeStack.html"){
			   $scope.nativeStackList =[{name:'Spring, Spring Cloud, Spring Data'},{name:'Spring, Spring Cloud, Spring XD'}];
			   $scope.submitnativeStack = function(){
			    	$scope.createCtrlScope.activeModule = "create_dataStore.html";
			   }
		   }  
	   });
	   
	   /******* Data store *******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_dataStore.html"){
			   $scope.dataStoreList = [{ web:[{name:'Mysql'}, {name:'Postgresql'}, {name:'Mongodb'}], iot:['Pivotal XD', 'GreenPlum']}];
			   $timeout(function(){
			   //$scope.$watch('formLoaded', function(){
				   $('#dataStore').multiselect({includeSelectAllOption: true});
				   //alert()
			   //})
			  },50)
			   
			   $scope.c_dataStoreList = $scope.dataStoreList[0][$scope.createCtrlScope.serviceMix.name.toLowerCase()]
			   $scope.submitdataStore = function(){
			       $scope.createCtrlScope.activeModule = "create_cachingSolution.html";
			   }
		   }
	   });
	   
	   /******* Caching Solution *******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_cachingSolution.html"){
			   $scope.cachingSolutionList = [{name:'Redis'},{name:'Mamcahce'}];
			   $scope.submitcachingSolution = function(){
				   $scope.createCtrlScope.activeModule = "create_UIgenPltfm.html";
			   }
			   
			   
		   }
	   });
	   
	   
	   /******* UI Generation *******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_UIgenPltfm.html"){
			   $scope.UIgenPltfmList = [{name:'Angularjs'},{name:'SpringMVCThymeleaf'}];
			   $timeout(function(){$("#cacheSolModal").modal('show');},100)
			   
			   $scope.submitcnfmUIgen = function(){
				   $("#cacheSolModal").modal('hide');
				   if(!$scope.createCtrlScope.confirm_UIGeneration){
					   $scope.createCtrlScope.activeModule = "create_IntgnPlfm.html";
				   }
			   }
			   
			   $scope.submitUIgenPltfm = function(){
				   $scope.createCtrlScope.activeModule = "create_IntgnPlfm.html";
			   }
		   }
	   });
	   
	   
	   /******* Integration Platform *******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_IntgnPlfm.html"){
			   $scope.intgnPltfmList = [{name:'RabbitMQ'}];
			   $timeout(function(){$("#intPfmModal").modal('show');},100)
			   
			   $scope.submitCnfIntPtfm = function(){
				   $("#intPfmModal").modal('hide');
				   if(!$scope.createCtrlScope.confirm_integrationPlatform){
					   $scope.createCtrlScope.activeModule = "create_folderGen.html";
				   }
			   }
			   
			   $scope.submitIntgnPlfm = function(){
				   $scope.createCtrlScope.activeModule = "create_folderGen.html";
			   }	   
		   }
	   });
	   
	   /******* Folder name generation and Final submission*******/
	   $scope.$watch('createCtrlScope.activeModule', function(){
		   if($scope.createCtrlScope.activeModule == "create_folderGen.html"){
			   
			   $scope.submitfolderGen = function(){
				   /********Submit Integration platform***********/ 
				   var dataP = Createservice_serv.createCtrlScope;
				   dataP = {
				    		"microservices":[dataP.cachingSolution.name],
				    		"folderName":dataP.folderGenName
				    		}
				   if(Createservice_serv.createCtrlScope.uiGenerationPlatform)
					   {dataP.microservices.push(Createservice_serv.createCtrlScope.uiGenerationPlatform.name)}
					
				   if(Createservice_serv.createCtrlScope.integrationPlatform)
					   {dataP.microservices.push(Createservice_serv.createCtrlScope.integrationPlatform.name)}   
				   
						   angular.forEach(Createservice_serv.createCtrlScope.dataStore, function(v,k){
							   dataP.microservices.push(v.name);
						   })
				   console.log(Createservice_serv.createCtrlScope)
				   CreateService_Fact.submit_newService(dataP).then(function(dataR){
						//alert('Success');
				   });
			   }   
		   }
	   });
   })
   
   .controller('calibrateCtrl', function ($scope) {
      
   })
   
   .controller('containerizeCtrl', function ($scope) {
      
   })