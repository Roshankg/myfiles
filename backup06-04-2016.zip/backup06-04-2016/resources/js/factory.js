AcnCloudStudio

.factory('CreateService_Fact', function($http, $q, UiNotification){
	return{
		submit_newService: function(dataP){
								var deferred = $q.defer();
								console.log(dataP);
								$http.post('buildSkelton', dataP).success(function(dataR) {
									UiNotification.addAlert({type: 'success', msg: 'Saved successfully!'});
									deferred.resolve(dataR);
							    }).error(function(error, status, headers, config) {
							    	  UiNotification.addAlert({type: 'danger', msg: 'Failed to Save'});
							    	  deferred.reject(error);
							    });
							    return deferred.promise;
		}
	}	
})