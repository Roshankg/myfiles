package org.springframework.samples.travel;

import java.security.Principal;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HotelsController {

	private BookingService bookingService;
	
	static int status = 0;

	@Inject
	public HotelsController(BookingService bookingService) {
		this.bookingService = bookingService;
	}

	@RequestMapping(value = "/hotels/search", method = RequestMethod.GET)
	public void search(SearchCriteria searchCriteria, Principal currentUser, Model model) {		
		if(status++ == 0){
			bookingService.createBasicData();
		}
		if (currentUser != null) {
			List<Booking> booking = bookingService.findBookings(currentUser.getName());
			model.addAttribute(booking);
		}
	}

	@RequestMapping(value = "/hotels", method = RequestMethod.GET)
	public String list(SearchCriteria criteria, Model model) {
		List<Hotel> hotels = bookingService.findHotels(criteria);		
		model.addAttribute(hotels);
		return "hotels/list";
	}


	@RequestMapping(value = "/hotels/{id}", method = RequestMethod.GET)
	public String show(@PathVariable Long id, Model model) {
		model.addAttribute(bookingService.findHotelById(id));
		return "hotels/show";
	}
	
	@RequestMapping(value = "/hotels/booking", method = RequestMethod.GET)
	public String bookHotelDetails(Model model, HttpServletRequest request) {
		Hotel hotel	=	(Hotel)request.getSession().getAttribute("hotelinfo");
		Booking booking = new Booking();
		booking.setHotel(hotel);
		//System.out.println(hotel.getName());
		model.addAttribute(booking);
		return "enterBookingDetails";
	}
	@RequestMapping(value = "/hotels/booking", method = RequestMethod.POST)
	public String bookHotel(@RequestParam("hotelId") Long id, @ModelAttribute Booking booking , HttpServletRequest request, Model model) {
		Hotel hotel	=	(Hotel)request.getSession().getAttribute("hotelinfo");
		booking.setHotel(hotel);
		try{
			User user	=bookingService.findUser(booking.getUser().getUsername());
		}catch (Exception e){
			model.addAttribute("error", "Not Valid User. Please try 'keith', 'erwin', 'jeremy'  as it is available.");
			return "enterBookingDetails";
		}
		
		booking	= bookingService.createBooking(id, booking.getUser().getUsername());
		model.addAttribute(booking);
		return "enterBookingDetails";
	}

	@RequestMapping(value = "/bookings/{id}", method = RequestMethod.DELETE)
	public String deleteBooking(@PathVariable Long id) {
		bookingService.cancelBooking(id);
		return "redirect:../hotels/search";
	}

}