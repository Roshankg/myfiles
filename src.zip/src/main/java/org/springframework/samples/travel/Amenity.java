package org.springframework.samples.travel;

public enum Amenity {
    OCEAN_VIEW, LATE_CHECKOUT, MINIBAR;
}