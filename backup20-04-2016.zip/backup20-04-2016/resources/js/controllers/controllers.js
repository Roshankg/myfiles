AcnCloudStudio
  
  .controller('LeftCtrl', function ($scope, $timeout, $rootScope) {
	  $scope.sideBar_items = [{name:'Create'}, {name:'Calibrate'}, {name:'Containerize'}]
	  
      $('#sideBar_toggleBtn').on('click', function () {
	      $('.row-offcanvas').toggleClass('active')
	  });
      
      $scope.sideBarElement_active = function(elem){
    	  $('.row-offcanvas').toggleClass('active');
    	  $scope.sideBar_activeItem = elem.$id;
    	  sessionStorage.sideBar_activeItem = $scope.sideBar_activeItem;
      } 
      if(sessionStorage.sideBar_activeItem){
    	  $scope.sideBar_activeItem = sessionStorage.sideBar_activeItem;
      }
      
   })

  .controller('dashboardCtrl', function ($scope) {
	  $scope.$parent.sideBar_activeItem = null;
   })
   
   .controller('createCtrl', function ($scope, $rootScope, $timeout, AcnStudio_Create, AcnStudio_CreateFactor) {
	   
	   $scope.createCtrlScope = {ms:{activeModule:''}};
	   //AcnStudio_Create.microServices = $scope.createCtrlScope;
	   
	   /********Microservices count*************/
	   $scope.microServices_countList = [1,2,3,4,5];
	   $scope.submit_microServices_count = function($event){
		   angular.element(event.target).hide();
		   $scope.createCtrlScope.render_ServiceScreens = true;
		   $scope.createCtrlScope.ms={};
		   
		   $scope.createCtrlScope.ms.headerQueue = [];
		   $scope.treeViewData=[];
		   $scope.createCtrlScope.ms.activeModule = "create_MicroService.html";
		   $timeout(function(){
			   $('#dataStore_field').multiselect({includeSelectAllOption: true});
		   },50)
		   $scope.createCtrlScope.activeMicroService = 1;
	   }
	   
	   $scope.serviceMixList =[{name:'Web'}];
	   
	   $scope.nativeStackList =[{name:'Spring Boot/ Spring Cloud/ Spring Data'}];
	   	   
	   $scope.dataStoreList = [{name:'Mysql'}, {name:'Postgresql'}, {name:'Mongodb'}];
	   
	   
	   $scope.cachingSolutionList = [{name:'Redis'},{name:'Memcached'}];
	   
	   $scope.UIgenPltfmList = [{name:'Angularjs'},{name:'SpringMVCThymeleaf'}];

	   $scope.intgnPltfmList = [{name:'RabbitMQ'}];
	   
	   $scope.submitMicroService = function(){
		   $rootScope.loading = true;
		   console.log($scope.createCtrlScope);
		   AcnStudio_Create.microServices[$scope.createCtrlScope.ms.microServiceName] = $scope.createCtrlScope.ms;
		   //**********Update the tree view data***************//*
		   $scope.updateTreeView();
		   
		   if($scope.createCtrlScope.activeMicroService< $scope.createCtrlScope.microServices_count){
			   $scope.createCtrlScope.activeMicroService++;
			   $scope.createCtrlScope.ms={};
			   $scope.createCtrlScope.ms.headerQueue = [];
			   $('#dataStore_field').multiselect("deselectAll", false);
			   $('#dataStore_field').multiselect('refresh');
			   $scope.createCtrlScope.ms.activeModule = "create_MicroService.html";
			   $timeout(function(){$rootScope.loading = false;},200);
		   }
		   else if($scope.createCtrlScope.activeMicroService == $scope.createCtrlScope.microServices_count){
			   $scope.createCtrlScope.ms={};
			   $scope.createCtrlScope.ms.headerQueue = [];
			   $scope.createCtrlScope.ms.activeModule = "create_folderGen.html";
			   $timeout(function(){$rootScope.loading = false;},200);
		   }
	   }
	   
	   
	   
	   /******* Folder name generation and Final submission*******/
	   			
			   $scope.submitfolderGen = function(){
				   /********Submit Folder***********/
			   		var dataP={
			   				"custommicroservices" : [],
			   				"microservices" : [],
			   				"folderName" : $scope.createCtrlScope.ms.folderGenName
			   		};
			   		
			   		
			   		angular.forEach(AcnStudio_Create.microServices, function(v, k){
			   			dataP.custommicroservices.push(k);
			   			
			   			angular.forEach(AcnStudio_Create.microServices[k], function(val, key){
			   				if(key !== 'activeModule' && key !== 'folderGenName' && key !== 'headerQueue' && key !=='microServiceName' && key!== 'viewToRender'){
			   					if(typeof(val) !== 'object' && dataP.microservices.indexOf(val) == '-1' && val !== undefined){
			   						dataP.microservices.push(val);
			   					}
			   					else if(dataP.microservices.indexOf(val) == '-1'){
			   						for(var i=0;i<=val.length;i++){
			   							if(dataP.microservices.indexOf(val[i]) == '-1' && val[i] !== undefined){
			   								dataP.microservices= dataP.microservices.concat(val[i]);
			   							}
			   						}
			   					}
			   				}
				   		})
			   		})
			   		
			   		AcnStudio_Create.microServices = {};
			   		
			   		if(dataP.custommicroservices.length>=1){
			   			/**********Submission of Micro-service to create***********/
				   		AcnStudio_CreateFactor.submit_newService(dataP).then(function(dataR){
				   			
					    });
			   		}
			   }   
		   
		   
		   $scope.updateTreeView = function(){
			   console.log(AcnStudio_Create.microServices);
			   var nodes = [];
			   $.each($scope.createCtrlScope.ms, function(key,val){
				   if(key !== 'activeModule' && key !== 'folderGenName' && key !== 'headerQueue' && key !=='microServiceName' && key!== 'viewToRender'){
					   if(typeof(val) !== 'object' && val !== undefined){
						   nodes.push({
	                           text: val
	                       });
					   }
					   else if(typeof(val) == 'object' && val !== undefined){
						   $.each(val, function(k,v){
							   nodes.push({
		                           text: v,
		                       });
						   })
					   }
				   }
			   })
			   $scope.treeViewData.push({
		                            text: $scope.createCtrlScope.ms.microServiceName,
		                            href: "'#"+$scope.createCtrlScope.ms.microServiceName+"'",
		                            tags: ['0'],
		                            nodes:nodes
		                          });
			   
			   $('#treeview4').treeview({
				     color: "#428bca",
				     data: $scope.treeViewData
			   });
		   }
   })
   
   .controller('calibrateCtrl', function ($scope) {
      
   })
   
   .controller('containerizeCtrl', function ($scope) {
      
   })
   