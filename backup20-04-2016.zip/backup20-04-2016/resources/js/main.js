AcnCloudStudio = angular.module('AcnCloudStudio',['ngMessages', 'ngAnimate', 'ngRoute', 'ui.bootstrap'])

.config(function($httpProvider, $routeProvider) {
	
	$httpProvider.interceptors.push('LoadingInterceptor');
	
    $routeProvider

        // Default route for the dashboard screen
        .when('/', {
            templateUrl : 'resources/views/dashboard.html',
            controller  : 'dashboardCtrl'
        })
        .when('/create', {
            templateUrl : 'resources/views/create.html',
            controller  : 'createCtrl'
        })
        .when('/calibrate', {
            templateUrl : 'resources/views/calibrate.html',
            controller  : 'calibrateCtrl'
        })
        .when('/containerize', {
            templateUrl : 'resources/views/containerize.html',
            controller  : 'containerizeCtrl'
        })
        .otherwise({
            redirectTo: '/'
        })
})